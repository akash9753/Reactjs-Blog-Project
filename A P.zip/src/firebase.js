import firebase from 'firebase/app';
import 'firebase/firestore';
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBSH88PDIJRzyJ_ll0PuPhGqslmTJilzqw",
  authDomain: "react-hooks-blog-ad67b.firebaseapp.com",
  projectId: "react-hooks-blog-ad67b",
  storageBucket: "react-hooks-blog-ad67b.appspot.com",
  messagingSenderId: "895489493193",
  appId: "1:895489493193:web:206ed17460d0fbf0592518"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const firestore = firebase.firestore;